// Copyright (c) 2019 Free2Play-Entertainment

#include "GameJoltPluginPCH.h"

IMPLEMENT_MODULE(FDefaultGameModuleImpl, GameJoltPlugin);

DEFINE_LOG_CATEGORY(GJAPI);